﻿using System;
using System.Linq;

namespace Brackets
{

    public interface IBrackets
    {
         char[] Bracketlist { get; set; }
         int _top { get; set; }
         void push(char ele);
         void pop();
         void display();
        bool IsStackEmpty();
    }

    class BracketStack : IBrackets
    {
        private static BracketStack instance;
        public char[] Bracketlist { get; set; }
        public int _top { get; set; }
        public int topElepos { get; set; }
       
        public static BracketStack getInstance(int size)
        {
            instance = new BracketStack(size);
            return instance;
        }
        public void display()
        {
            Console.WriteLine("Stack elements are\n" + string.Join(" ", Bracketlist));
        }

        public void pop()
        {
            _top--;
        }

        public void push(char ele)
        {
            Bracketlist[++_top] = ele;
        }

        public bool IsMatch(char text)
        {
            char topEle = Bracketlist[_top];
            return ((topEle == '(' && text == ')') || (topEle == '{' && text == '}') || (topEle == '[' && text == ']'));
        }

        private BracketStack(int size)
        {
            _top = -1;
            Bracketlist = new char[size];
        }

        public bool IsStackEmpty() => _top == -1;
        

    }

    public class Week1_Brackets
    {
        public static string text { get; set; }

        public static void Main(string[] args)
        {
            text = Console.ReadLine();
            Console.WriteLine(CheckBracketsMatch());
        }

        public static string CheckBracketsMatch()
        {
            BracketStack Stack = BracketStack.getInstance(text.Length);

            char[] OpeningBrackets = new[] { '(', '{', '[' };
            char[] ClosingBrackets = new[] { ')', '}', ']' };

            string message = string.Empty;
            for (int i = 0; i < text.Length; i++)
            {
                if (OpeningBrackets.Contains(text[i]))
                {
                    Stack.push(text[i]);
                    Stack.topElepos = i + 1;
                }
                else if (ClosingBrackets.Contains(text[i]))
                {
                    if (!Stack.IsStackEmpty() && Stack.IsMatch(text[i]))
                        Stack.pop();
                    else
                    {
                        message = "" + (i + 1);
                        break;
                    }

                }
            }

            if (Stack._top > -1 || message.Length > 0)
                return(message.Length> 0?message:Stack.topElepos.ToString());
            else 
                return("Success");
        }
    }
}
