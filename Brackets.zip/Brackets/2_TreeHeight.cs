﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week1_TreeHeight
{

    public class TreeParentChild
    {
        public long nodeValue;
        public TreeParentChild ChildNode { get; set; }

        public TreeParentChild()
        {
            this.nodeValue = 0;
            this.ChildNode = null;
        }

        public void AddChildNode(long _nodeValue)
        {
            TreeParentChild currentChild = this.ChildNode;

            if(currentChild == null)
            {
                this.ChildNode = new TreeParentChild();
                this.ChildNode.nodeValue = _nodeValue;
                return;
            }

            while (currentChild.ChildNode != null)
                currentChild = currentChild.ChildNode; 

            currentChild.ChildNode = new TreeParentChild();
            currentChild.ChildNode.nodeValue = _nodeValue;
        }
    }

    public class TreeHeight
    {
        public static long NumberOfNodes { get; set; }
        public static long[] TreeNodes { get; set; }
        public static TreeParentChild[] ParentChild { get; set; }
        private static long[] Counter; 

        static TreeHeight()
        {
            NumberOfNodes = new Int64();
        }
            
        public static void Main(string[] args)
        {
            NumberOfNodes = Convert.ToInt64(Console.ReadLine());
            string inputArray = Console.ReadLine();
            TreeNodes = Array.ConvertAll<string, long>(inputArray.Split(' '), x => Convert.ToInt64(x));
            try
            {


                long height = FindHeightOfTree();

                Console.WriteLine(height);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static long FindHeightOfTree()
        {
            ParentChild = new TreeParentChild[TreeNodes.Length];
            long rootIndex = 0;
            Counter = new long[TreeNodes.Length];
            for (long i = 0; i < TreeNodes.Length; i++)
            {
                if (ParentChild[i] == null)
                    InitializeTreeParrent(i);

                if (TreeNodes[i] == -1)
                    rootIndex = i;
                else
                {
                    if (ParentChild[TreeNodes[i]] == null)
                        InitializeTreeParrent(TreeNodes[i]);

                    ParentChild[TreeNodes[i]].AddChildNode(i);
                }
            }

            return GetHeightOfTree(rootIndex);
        }

        private static void InitializeTreeParrent(long i)
        {
            
                ParentChild[i] = new TreeParentChild();
                ParentChild[i].nodeValue = i;
            
        }

        private static long GetHeightOfTree(long rootindex)
        {
            TreeParentChild Node = ParentChild[rootindex];

            if (Node.ChildNode == null)
                return 1;

            List<long> HeightArray = new List<long>();
            while (Node.ChildNode !=null)
            {
                HeightArray.Add(GetHeightOfTree(Node.ChildNode.nodeValue) + 1);
                Node = Node.ChildNode;
            }

            return (HeightArray.Max());
        }

    }
}
