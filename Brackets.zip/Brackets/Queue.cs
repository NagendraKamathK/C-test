﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week1
{
    public interface ITreeQueue
    {
        int[] nodeList { get; set; }
        int front { get; set; }
        void EnQueue(int node);
        int Dequeue();
        void display();
        bool IsEmpty();
        bool IsFull();
    }

    class TreQueue : ITreeQueue
    {
        private static TreQueue instance;
        public int[] nodeList { get; set; }
        public int front { get; set; }

        public static TreQueue getInstance(int size)
        {
            instance = new TreQueue(size);
            return instance;
        }
        public void display()
        {
            Console.WriteLine("Stack elements are\n" + string.Join(" ", nodeList));
        }

        public int Dequeue()
        {
            int frontnode = -1;
            if (!IsEmpty())
                frontnode = nodeList[front++];

            return frontnode;
        }

        public void EnQueue(int node)
        {
            if (!IsFull())
                nodeList[++front] = node;
        }


        private TreQueue(int size)
        {
            front = -1;
            nodeList = new int[size];
        }

        public bool IsEmpty() => front == -1;
        public bool IsFull() => front == nodeList.Length - 1;
    }

}
