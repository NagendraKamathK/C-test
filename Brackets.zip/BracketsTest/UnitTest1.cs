﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Brackets;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BracketsTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            string folder = @"E:\Education\Coding\C#\Programming-Assignment-1\tree_height\tests";

            DirectoryInfo di = new DirectoryInfo(folder);
            FileInfo[] files = di.GetFiles().Where(x=>!Path.HasExtension(x.FullName) && Convert.ToInt32(x.Name)>9 ).ToArray();
          //  Parallel.ForEach(files, (file) =>
            foreach(var file in files)
            {
                try
                {
                    string input = File.ReadAllText(file.FullName);

                    Week1_TreeHeight.TreeHeight.NumberOfNodes = Convert.ToInt64(input.Split('\n').First());

                    Week1_TreeHeight.TreeHeight.TreeNodes = Array.ConvertAll(input.Split('\n').Skip(1).First().Split(' '), x => Convert.ToInt64(x));
                    /// Week1_Brackets.text = File.ReadAllText(file.FullName);
                    string output = Week1_TreeHeight.TreeHeight.FindHeightOfTree().ToString();
                    string ActualOutput = File.ReadAllText(file.FullName + ".a");

                    if (output != Regex.Replace(ActualOutput, @"\t|\n|\r", ""))
                    {
                        Console.WriteLine("MISS MATCH " + file.Name + " NODE SIZE:" + Week1_TreeHeight.TreeHeight.NumberOfNodes + "OUTPUT:" + output + " ACTUAL OUTPUT:" + ActualOutput);
                        //  break;
                    }
                    else
                        Console.WriteLine(file.Name + " NODE SIZE:" + Week1_TreeHeight.TreeHeight.NumberOfNodes + "OUTPUT:" + output + " ACTUAL OUTPUT:" + ActualOutput);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(file.Name + " Has a problem. Message:\n" + ex.Message);
                }
            }//);
        }

        [TestMethod]
        public void TestMethod2()
        {
            string folder = @"E:\Education\Coding\C#\Programming-Assignment-1\check_brackets_in_code\tests";

            DirectoryInfo di = new DirectoryInfo(folder);
            FileInfo[] files = di.GetFiles().Where(x => !Path.HasExtension(x.FullName)).ToArray();
            foreach (var file in files)
            {
                try
                {
                    Week1_Brackets.text = File.ReadAllText(file.FullName);
                    string output = Week1_Brackets.CheckBracketsMatch();
                    string ActualOutput = File.ReadAllText(file.FullName + ".a");

                    if (output != Regex.Replace(ActualOutput, @"\t|\n|\r", ""))
                    {
                        Console.WriteLine(file.Name + " OUTPUT:" + output + " ACTUAL OUTPUT:" + ActualOutput);
                        break;
                    }
                    else
                        Console.WriteLine(file.Name + " OUTPUT:" + output + " ACTUAL OUTPUT:" + ActualOutput);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(file.Name + "Has a problem");
                }
            }

        }
    }
}
